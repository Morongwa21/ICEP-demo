// Define job listings data (dummy data for demonstration purposes)
var jobListings = [
  {
    id: 1,
    title: "Web Developer",
    skills: ["HTML", "CSS", "JavaScript"],
    experience: "2 years",
    location: "Midrand",
  },
  {
    id: 2,
    title: "Software Engineer",
    skills: ["Java", "Python", "SQL"],
    experience: "3 years",
    location: "Sandton",
  },
  {
    id:3 ,
    title: "Software Developer",
    skills: ["c++", "HTML", "SQL"],
    experience: "2 years",
    location: "Pretoria",
  },
  {
    id: 4,
    title: "System Analyst",
    skills: ["Extensive knowledge in computer programming", "analytical problem solving skills", "MsOffice"],
    experience: "5 years",
    location: "Gqeberha",
  },
  {
    id: 5,
    title: "Software Developer Graduate program",
    skills: ["Java", "Python", "SQL"],
    experience: "none",
    location: "Pretoria",
  },
  
];
