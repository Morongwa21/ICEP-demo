document.addEventListener("DOMContentLoaded", function() {
  // Retrieve the login form element
  var login = document.getElementById("login");

  // Add event listener for form submission
  login.addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get the form inputs
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Perform login authentication
   /* if (authenticateUser(email, password)) {
      // Redirect to the profile page on successful login
      window.location.href = "profile.html";
    } else {
      // Display an error message if login fails
      alert("Invalid email or password. Please try again.");
    }

    // Reset the form
    loginForm.reset();*/
	alert("Login Successful!");
	window.location.href="reg.html";
  });
  });

  /*// Function to authenticate the user
  function authenticateUser(email, password) {
    // Implement your authentication logic here
    // You can make API calls, check credentials against a database, etc.
    // Return true if the user is authenticated, false otherwise
    // For demo purposes, you can hardcode the credentials for testing
    var validEmail = "user@example.com";
    var validPassword = "password";

    return email === validEmail && password === validPassword;
  }
});*/
