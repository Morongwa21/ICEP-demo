document.addEventListener("DOMContentLoaded", function() {
    // Retrieve user list from the server or local storage
    var users = [
        { name: "Lerato Mdeni", email: "lee@gmail.com" },
        { name: "Morongwa Mathebe", email: "rongwa@yahoo.com" },
        { name: "Saul Baloyi", email: "bsaul8@nedna.com" }
    ];

    // Display the user list
    var usersList = document.getElementById("usersList");
    users.forEach(function(user) {
        var userElement = document.createElement("div");
        userElement.classList.add("user");
        userElement.innerHTML = "<p><strong>Name:</strong> " + user.name + "</p>";
        userElement.innerHTML += "<p><strong>Email:</strong> " + user.email + "</p>";

        // Add a button to connect with the user
        var connectButton = document.createElement("button");
        connectButton.textContent = "Connect";
        connectButton.addEventListener("click", function() {
            // Implement the connection logic here, e.g., sending a connection request
            alert("Connection request sent to " + user.name);
        });
        userElement.appendChild(connectButton);

        usersList.appendChild(userElement);
    });
});
