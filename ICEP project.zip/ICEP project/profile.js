document.addEventListener("DOMContentLoaded", function() {
    // Retrieve user object from local storage
    var user = JSON.parse(localStorage.getItem("user"));
  var jobRecommendations = [
    {
      title: "Web developer",
      company: "ABSA",
      location: "Johannesburg, Sooth Africa",
	  Skills: "HTML, JavaScript, CSS",
	 Experience: "3 Years"
	 
	  
    },
	{
		title: "Software developer",
      company: "Doloitte",
      location: "Midrand, South Africa",
	  Skills: "C++, JavaScript, CSS,HTML,SQL",
	 Experience: "1 Year"
	},
	{
		title: "Software developement Graduate Program",
      company: "PwC",
      location: "Midrand, South Africa",
	  Skills: "C#, JavaScript, CSS,HTML,SQL",
	 Experience: "None"
	},
	{
		title: "Information Technology Graduate Program",
      company: "AfrikaTikkun",
      location: "Randburg, South Africa",
	  Skills: "java,Electrical, CSS,HTML",
	 Experience: "None"
	},
	{
		title: "System analysis Graduate Program",
      company: "Nedbank",
      location: "Sandton, South Africa",
	  Skills: "C#, JavaScript, CSS,HTML,SQL",
	 Experience: "None"
	},
		
];
    // Display user information
    var profileInfo = document.getElementById("profile");
    profileInfo.innerHTML += "<p><strong>Name:</strong> " + user.firstname + "</p>";
	profileInfo.innerHTML += "<p><strong>Surname:</strong> " + user.surname + "</p>";
    profileInfo.innerHTML += "<p><strong>Email:</strong> " + user.email + "</p>";
    profileInfo.innerHTML += "<p><strong>Skills:</strong> " + user.skills + "</p>";
	profileInfo.innerHTML += "<p><strong>Educational Background:</strong> " + user.educational_background + "</p>";
    profileInfo.innerHTML += "<p><strong>Work Experience:</strong> " + user.work_experience + "</p>";
    profileInfo.innerHTML += "<p><strong>Role of Interests:</strong> " + user.role_interests + "</p>";
	var jobRecommendationsElement = document.getElementById("jobRecommendations");

  // Display the job recommendations
  for (var i = 0; i < jobRecommendations.length; i++) {
    var job = jobRecommendations[i];

    var jobElement = document.createElement("div");
    jobElement.classList.add("job");

    var titleElement = document.createElement("h3");
	    titleElement.textContent = job.title;

    var companyElement = document.createElement("p");
    companyElement.textContent = "Company: " + job.company;

    var locationElement = document.createElement("p");
    locationElement.textContent = "Location: " + job.location;
	
var descriptionElement = document.createElement("p");
    descriptionElement.textContent = job.Skills;
	
var experienceElement = document.createElement("p");
    experienceElement.textContent = job.Experience;
	
    jobElement.appendChild(titleElement);
    jobElement.appendChild(companyElement);
    jobElement.appendChild(locationElement);
    jobElement.appendChild(descriptionElement);
 jobRecommendationsElement.appendChild(jobElement);
  }
  /*function getSkillLink(skill) {
    // Map each skill to its respective link (dummy data for demonstration purposes)
    var skillLinks = {
        "HTML": "https://www.w3schools.com/html/",
        "CSS": "https://www.w3schools.com/css/",
        "JavaScript": "https://www.w3schools.com/js/",
        "Java": "https://www.oracle.com/java/",
        "Python": "https://www.python.org/",
        "SQL": "https://www.w3schools.com/sql/"
    };

    // Return the link for the given skill
    return skillLinks[skill] || "#";*/
});
