
 document.getElementById("registration-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission behavior

    // Get form values
    var firstname = document.getElementById("firstname").value;
	var surname = document.getElementById("surname").value;
    var email = document.getElementById("email").value;
    var educational_background = document.getElementById("educational_background").value;
    var skills = document.getElementById("skills").value;
    var work_experience = document.getElementById("work_experience").value;
    var role_Interests = document.getElementById("role_interests").value;

    //User object
    var user = {
        firstname: firstname,
		surname: surname,
        email: email,
        educational_background: educational_background,
        skills: skills,
        work_experience: work_experience,
        role_interests: role_interests
    };

   localStorage.setItem("user", JSON.stringify(user));

    // Redirect to profile page or perform other actions
    window.location.href = "profile.html";
});
