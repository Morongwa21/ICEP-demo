document.addEventListener("DOMContentLoaded", function() {
  // Retrieve the sign-up form element
  var signup = document.getElementById("signup");

  // Add event listener for form submission
  signup.addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission behavior

    // Get the form inputs
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Store the user information (e.g., in localStorage or a database)
    // Here, we're storing it in localStorage for demonstration purposes
    var user = {
      name: name,
      email: email,
      password: password
    };
	alert("Registration Successful!");
   // localStorage.setItem("users", JSON.stringify(users));

    // Redirent to registration page
    window.location.href = "reg.html";
  });
});

